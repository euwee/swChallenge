package com.swc.webMailClient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebMailClientApplication {
	
	/*public WebMailClientApplication() {
		// TODO Auto-generated constructor stub
		//EMailSendController mailsend = new EMailSendController(); 
		//mailsend.emailSendHandler("zhezhelaw@gmail.com, euweetan@gmail.com, euweetan@hotmail.com", 
		//		"euweetan@gmail.com", "euweetan@hotmail.com", "Testing Mail Setting", "Hello World Thank you Very much");
	}*/

	public static void main(String[] args) {
		SpringApplication.run(WebMailClientApplication.class, args);
		
	}
}
