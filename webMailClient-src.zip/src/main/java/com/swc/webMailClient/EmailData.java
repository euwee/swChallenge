package com.swc.webMailClient;

public class EmailData {
	private String recipients;
	private String ccTo;
	private String bccTo;
	private String subject;
	private String message;
	private String result;
	
	/**
	 *
	 * @return recipients email addresses
	 */
	public String getRecipients() {
		return recipients;
	}
	
	/**
	 * 
	 * @param recipients email addresses
	 */
	public void setRecipients(String recipients) {
		this.recipients = recipients;
	}
	
	/**
	 * 
	 * @return CC recipients email addresses
	 */
	public String getCcTo() {
		return ccTo;
	}
	
	/**
	 * 
	 * @param ccTo CC recipients email addresses
	 */
	public void setCcTo(String ccTo) {
		this.ccTo = ccTo;
	}
	
	/**
	 * 
	 * @return BCC recipients email addresses
	 */
	public String getBccTo() {
		return bccTo;
	}
	
	/**
	 * 
	 * @param bccTo BCC recipients email addresses
	 */
	public void setBccTo(String bccTo) {
		this.bccTo = bccTo;
	}
	
	/**
	 * 
	 * @return return the subject title of the email message
	 */
	public String getSubject() {
		return subject;
	}
	
	/**
	 * 
	 * @param subject The subject title of the email message
	 */
	public void setSubject(String subject) {
		this.subject = subject;
	}
	
	/**
	 * 
	 * @return the content of the email
	 */
	public String getMessage() {
		return message;
	}
	
	/**
	 * 
	 * @param message the content of the email
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	
	/**
	 * 
	 * @return the result of the message delivery
	 */
	public String getResult() {
		return this.result;
	}
	
	/**
	 * 
	 * @param result the result of the message delivery
	 */
	public void setResult(String result) {
		this.result = result;
	}

}
