package com.swc.webMailClient;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.ResponseBody;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.respon;
import org.springframework.web.servlet.ModelAndView;




@Controller
public class EMailSendController {
	private final String CONTROLLERNAME = "EMailSendController";
	private final String PRIMARYMAIL = "SendGrid";
	private final String SECONDARYMAIL = "MailGun";
	
	private JavaMailSenderImpl sender;
    private MimeMessage message;
    private MimeMessageHelper helper;
    private ModelAndView mv;

    
	public EMailSendController() {
		sender = new JavaMailSenderImpl();
        message = sender.createMimeMessage();
        helper = new MimeMessageHelper(message);
        
		sender.setHost("smtp.sendgrid.net");
        sender.setPort(587);
        sender.setUsername("apikey");
        sender.setPassword("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");
        sender.setProtocol("smtp");

	}
	
	@RequestMapping("/")
	public String indexPage() {
		System.out.println("In Index Page method");
		return "index";
	}
	
	
	/**
	 * 
	 * @param edata The web form data inserted by the user
	 * @return ModelAndView class of Spring Framework
	 */
	@RequestMapping("/sendmail")	
	public ModelAndView emailSendHandler(@ModelAttribute EmailData edata) {
		System.out.println("Hello I am In Controller " + edata.getMessage());
		mv = new ModelAndView();
		
		try {
			sendEmailPrimary(edata.getRecipients(),edata.getCcTo(), edata.getBccTo(), edata.getSubject(),edata.getMessage());
			System.out.println(CONTROLLERNAME + "Email Sent: " + PRIMARYMAIL);
			edata.setResult("Your message has been successfully sent. Thank you");
			mv.setViewName("result");
			mv.addObject("EmailData", edata);

		}catch(MessagingException me) {
			System.out.println("Primary Email Fail. Reason: " + me.getMessage());
			try {
				sendEmailSecondary(edata.getRecipients(),edata.getCcTo(), edata.getBccTo(), edata.getSubject(), edata.getMessage());
				System.out.println(CONTROLLERNAME + "Email Sent: " + SECONDARYMAIL);
				edata.setResult("Your message has been successfully sent. Thank you");
				mv.setViewName("result");
				mv.addObject("EmailData", edata);
			
			}catch(Exception ex) {
				System.out.println(CONTROLLERNAME + " Reason: Email Sent Fail " + SECONDARYMAIL + " " + me.getMessage());
				edata.setResult("Sorry, we fail to deliver your message. "
						+ "<br/> Please contact us at support@siteblogging.com "
						+ "<br/> Error message: " + me.getMessage());
				mv.setViewName("error");
				mv.addObject("EmailData", edata);
			}
			//me.printStackTrace();
		}
		return mv;
	}
	
	private void sendEmailPrimary(String recipient, String cc, String bcc, String subject, String content) throws MessagingException{
		
		if (recipient.length() == 0) {
			throw new MessagingException("No Primary Recipient. At least one recipient required.");
		}else {
			helper.setTo(textToArray(recipient));
		}
        
        if (cc.length() > 0 ) {
        	helper.setCc(textToArray(cc));
        }
        if ( bcc.length() > 0) {
        	helper.setBcc(textToArray(bcc));
        }
        
        helper.setSubject(subject);
        helper.setText(content);
        
        sender.send(message);
        System.out.println(PRIMARYMAIL + ": Message Sent to: " + recipient);

	}	
	
	private void sendEmailSecondary(String recipient, String cc, String bcc, String subject, String content) throws MessagingException{
       
        sender.setHost("smtp.mailgun.org");
        sender.setPort(587);
        sender.setUsername("postmaster@sandbox9ccf828de814428198cd6a220e865877.mailgun.org");
        sender.setPassword("a81ef17b73dc4f8332613c549269c284-8b7bf2f1-828a3ae3");
        sender.setProtocol("smtp");

        if (recipient.length() > 0) {
        	helper.setTo(textToArray(recipient));
        }else {
        	throw new MessagingException("No primary recipient. At least one recipient required.");
        }
        if (cc.length() > 0) {        
        	helper.setCc(textToArray(cc));
        }
        if (cc.length() > 0) {
        	helper.setBcc(textToArray(bcc));
        }
        helper.setSubject(subject);
        helper.setText(content);

        sender.send(message);
        System.out.println(SECONDARYMAIL + ": Message Sent to: " + recipient);
        
	}
	
	private String[] textToArray(String text) {
		return text.split(",");
	}

}
